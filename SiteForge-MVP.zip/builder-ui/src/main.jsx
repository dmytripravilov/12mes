import React, { useState, useEffect } from 'react'
import { createRoot } from 'react-dom/client'

const API = (path, opts={}) => fetch(`http://localhost:8085${path}`, { headers:{'Content-Type':'application/json'}, ...opts }).then(r=>r.json())

function App(){
  const [siteId,setSiteId]=useState(1)
  const [pages,setPages]=useState([])
  const [slug,setSlug]=useState('index')
  const [title,setTitle]=useState('Home')
  const [text,setText]=useState('Hello from SiteForge')

  useEffect(()=>{ API(`/pages?siteId=${siteId}`).then(setPages) },[siteId])

  const addPage = async () => {
    const blocks=[{type:'hero',text},{type:'text',text:'Lorem ipsum'}]
    const res = await API('/pages',{method:'POST',body:JSON.stringify({site_id:siteId,slug,title,blocks})})
    setPages(p=>[...p,res])
  }

  return <div style={{fontFamily:'system-ui',padding:16}}>
    <h1>SiteForge Builder</h1>
    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
      <section>
        <h3>Create Page</h3>
        <label>Site ID <input value={siteId} onChange={e=>setSiteId(parseInt(e.target.value||'1'))}/></label><br/>
        <label>Slug <input value={slug} onChange={e=>setSlug(e.target.value)}/></label><br/>
        <label>Title <input value={title} onChange={e=>setTitle(e.target.value)}/></label><br/>
        <label>Hero Text <input value={text} onChange={e=>setText(e.target.value)}/></label><br/>
        <button onClick={addPage}>Save Page</button>
      </section>
      <section>
        <h3>Pages</h3>
        <ul>{pages.map(p=><li key={p.id}><b>{p.slug}</b> — {p.title}</li>)}</ul>
        <p style={{opacity:.6}}>Publish via: <code>POST http://localhost:8080/api/sites/{siteId}/publish</code></p>
      </section>
    </div>
  </div>
}

createRoot(document.getElementById('root')).render(<App/>)
