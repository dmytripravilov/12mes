# SiteForge-MVP

**Goal:** выглядеть как проект разработчика ~4 года опыта, но с «прорывом» в архитектуре:
микросервисы, CI-ready структура, аккуратные интерфейсы.

Сервисы:
- **gateway-java**: Spring Boot шлюз + dev-JWT, эндпойнты auth, publish.
- **cms-php**: Slim + Postgres. CRUD: tenants/sites/pages, JSON-блоки.
- **worker-python**: FastAPI билдёр — забирает страницы из CMS, генерит статический HTML, грузит в MinIO (S3).
- **builder-ui**: React + Vite — простой редактор блоков и публикация.

Инфраструктура:
- **docker-compose**: postgres, minio; сервисы связаны сеткой.
- **Makefile**: build/up/down/smoke.
- **README**: quickstart, маршруты, dev-токен.

## Quickstart
```bash
docker compose build
docker compose up -d

# dev token
TOKEN=dev-please-dont-use-in-prod

# создать tenant
curl -s -X POST http://localhost:8085/tenants -H "Content-Type: application/json" -d '{"name":"Acme"}' | jq

# создать сайт
curl -s -X POST http://localhost:8085/sites -H "Content-Type: application/json" -d '{"tenant_id":1,"handle":"acme-site","title":"Acme Landing"}' | jq

# создать страницу
curl -s -X POST http://localhost:8085/pages -H "Content-Type: application/json" -d '{"site_id":1,"slug":"index","title":"Home","blocks":[{"type":"hero","text":"Hello from SiteForge"}]}' | jq

# дернуть публикацию через gateway
curl -s -X POST "http://localhost:8080/api/sites/1/publish" -H "Authorization: Bearer $TOKEN" | jq
```

## Где артефакты?
- MinIO (S3-совместимый): http://localhost:9001 (консоль) / http://localhost:9000 (API)
- Билд складывает в `site-<ID>/index.html` и `site-<ID>/<slug>.html`

> Все секреты dev-уровня, не для продакшна.