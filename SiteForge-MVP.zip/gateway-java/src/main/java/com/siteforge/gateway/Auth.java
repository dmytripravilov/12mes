package com.siteforge.gateway;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.crypto.MACVerifier;
import org.springframework.stereotype.Component;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
@Component
public class Auth {
  private final byte[] secret = System.getenv().getOrDefault("JWT_HS256_SECRET","DEV_SECRET").getBytes(StandardCharsets.UTF_8);
  public boolean isOk(String header){
    try{
      if(header==null || !header.startsWith("Bearer ")) return false;
      var token = header.substring(7);
      var jws = JWSObject.parse(token);
      var ok = jws.verify(new MACVerifier(secret));
      if(!ok) return false;
      var payload = jws.getPayload().toJSONObject();
      var exp = (Number) payload.get("exp");
      return exp==null || Instant.now().getEpochSecond() < exp.longValue();
    }catch(Exception e){ return false; }
  }
}
