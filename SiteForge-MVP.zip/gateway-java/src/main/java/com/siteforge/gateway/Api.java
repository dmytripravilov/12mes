package com.siteforge.gateway;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;
import java.util.*;
@RestController
@RequestMapping("/api")
public class Api {
  private final RestClient http = RestClient.create();
  private final Auth auth;
  private final String worker = System.getenv().getOrDefault("WORKER_BASE","http://worker-python:8070");
  public Api(Auth auth){ this.auth = auth; }

  @PostMapping("/sites/{id}/publish")
  public ResponseEntity<?> publish(@RequestHeader("Authorization") String a, @PathVariable("id") String id){
    if(!auth.isOk(a)) return ResponseEntity.status(401).body(Map.of("error","invalid_token"));
    Map resp = http.post().uri(worker + "/build?siteId=" + id).retrieve().body(Map.class);
    return ResponseEntity.ok(resp);
  }

  @GetMapping("/healthz")
  public Map<String,String> h(){ return Map.of("ok","true"); }
}
