from fastapi import FastAPI, Query
import os, requests, io
import boto3
from jinja2 import Template

CMS = os.getenv("CMS_BASE","http://cms-php:8085")
S3_ENDPOINT = os.getenv("S3_ENDPOINT","http://minio:9000")
S3_ACCESS_KEY = os.getenv("S3_ACCESS_KEY","minioadmin")
S3_SECRET_KEY = os.getenv("S3_SECRET_KEY","minioadmin")
S3_BUCKET = os.getenv("S3_BUCKET","siteforge")

app = FastAPI(title="SiteForge Worker", version="0.1.0")

def s3():
    return boto3.client("s3",
        endpoint_url=S3_ENDPOINT,
        aws_access_key_id=S3_ACCESS_KEY,
        aws_secret_access_key=S3_SECRET_KEY,
    )

HTML_BASE = Template("""<!doctype html>
<html><head><meta charset="utf-8"><title>{{ title }}</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>body{font-family:system-ui,Segoe UI,Roboto,Arial;margin:2rem;line-height:1.5} .hero{font-size:2rem;font-weight:700;margin:1rem 0}</style>
</head><body>
<h1>{{ title }}</h1>
{% for b in blocks %}
  {% if b.type == 'hero' %}<div class="hero">{{ b.text }}</div>{% endif %}
  {% if b.type == 'text' %}<p>{{ b.text }}</p>{% endif %}
{% endfor %}
<footer><small>Built by SiteForge</small></footer>
</body></html>""")

@app.get("/health")
def health(): return {"status":"ok"}

@app.post("/build")
def build(siteId: int = Query(..., ge=1)):
    # Ensure bucket
    c = s3()
    try:
        c.head_bucket(Bucket=S3_BUCKET)
    except Exception:
        c.create_bucket(Bucket=S3_BUCKET)

    pages = requests.get(f"{CMS}/pages", params={"siteId": siteId}, timeout=10).json()
    if not isinstance(pages, list):
        return {"error":"no_pages","siteId":siteId}

    base_key = f"site-{siteId}"
    home_key = f"{base_key}/index.html"
    for p in pages:
        html = HTML_BASE.render(title=p.get("title") or p.get("slug","page"), blocks=p.get("blocks") or [])
        key = f"{base_key}/{p.get('slug','page')}.html"
        c.put_object(Bucket=S3_BUCKET, Key=key, Body=html.encode("utf-8"), ContentType="text/html")
        if p.get("slug") == "index":  # copy to index.html
            c.put_object(Bucket=S3_BUCKET, Key=home_key, Body=html.encode("utf-8"), ContentType="text/html")

    url = f"{S3_ENDPOINT}/{S3_BUCKET}/{base_key}/index.html"
    return {"status":"built","siteId":siteId,"artifact":url}
