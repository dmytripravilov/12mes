<?php
declare(strict_types=1);
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;
require __DIR__.'/../vendor/autoload.php';
require __DIR__.'/../src/db.php';

$app = AppFactory::create();
$app->addBodyParsingMiddleware();

$app->get('/health', function(Request $r, Response $res){
  $res->getBody()->write(json_encode(['status'=>'ok']));
  return $res->withHeader('Content-Type','application/json');
});

$app->post('/tenants', function(Request $r, Response $res){
  $data = $r->getParsedBody();
  $pdo = db();
  $stmt = $pdo->prepare('INSERT INTO tenants(name) VALUES(:n) RETURNING id,name,created_at');
  $stmt->execute([':n'=>$data['name'] ?? 'Untitled']);
  $out = $stmt->fetch(PDO::FETCH_ASSOC);
  $res->getBody()->write(json_encode($out));
  return $res->withHeader('Content-Type','application/json');
});

$app->post('/sites', function(Request $r, Response $res){
  $d = $r->getParsedBody();
  $pdo = db();
  $stmt = $pdo->prepare('INSERT INTO sites(tenant_id,handle,title) VALUES(:t,:h,:ti) RETURNING id,tenant_id,handle,title,created_at');
  $stmt->execute([':t'=>$d['tenant_id'],':h'=>$d['handle']??null,':ti'=>$d['title']??null]);
  $res->getBody()->write(json_encode($stmt->fetch(PDO::FETCH_ASSOC)));
  return $res->withHeader('Content-Type','application/json');
});

$app->get('/sites', function(Request $r, Response $res){
  $tenant = $r->getQueryParams()['tenantId'] ?? null;
  $pdo = db();
  $stmt = $pdo->prepare('SELECT * FROM sites WHERE tenant_id=:t');
  $stmt->execute([':t'=>$tenant]);
  $res->getBody()->write(json_encode($stmt->fetchAll(PDO::FETCH_ASSOC)));
  return $res->withHeader('Content-Type','application/json');
});

$app->post('/pages', function(Request $r, Response $res){
  $d = $r->getParsedBody();
  $pdo = db();
  $stmt = $pdo->prepare('INSERT INTO pages(site_id,slug,title,blocks) VALUES(:s,:sl,:ti,CAST(:b AS JSON)) RETURNING id,site_id,slug,title,blocks');
  $stmt->execute([':s'=>$d['site_id'],':sl'=>$d['slug'],':ti'=>$d['title']??null,':b'=>json_encode($d['blocks'] ?? [])]);
  $res->getBody()->write(json_encode($stmt->fetch(PDO::FETCH_ASSOC)));
  return $res->withHeader('Content-Type','application/json');
});

$app->get('/pages', function(Request $r, Response $res){
  $site = $r->getQueryParams()['siteId'] ?? null;
  $pdo = db();
  $stmt = $pdo->prepare('SELECT * FROM pages WHERE site_id=:s ORDER BY id');
  $stmt->execute([':s'=>$site]);
  $res->getBody()->write(json_encode($stmt->fetchAll(PDO::FETCH_ASSOC)));
  return $res->withHeader('Content-Type','application/json');
});

$app->run();
