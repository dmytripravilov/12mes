<?php
function db() {
  static $pdo = null;
  if ($pdo) return $pdo;
  $dsn = getenv('DB_DSN') ?: 'pgsql:host=localhost;port=5432;dbname=siteforge';
  $user = getenv('DB_USER') ?: 'postgres';
  $pass = getenv('DB_PASS') ?: 'postgres';
  $pdo = new PDO($dsn, $user, $pass);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  // migrations
  $pdo->exec('CREATE TABLE IF NOT EXISTS tenants (id SERIAL PRIMARY KEY, name TEXT NOT NULL, created_at TIMESTAMP DEFAULT NOW())');
  $pdo->exec('CREATE TABLE IF NOT EXISTS sites (id SERIAL PRIMARY KEY, tenant_id INT NOT NULL, handle TEXT, title TEXT, created_at TIMESTAMP DEFAULT NOW())');
  $pdo->exec('CREATE TABLE IF NOT EXISTS pages (id SERIAL PRIMARY KEY, site_id INT NOT NULL, slug TEXT, title TEXT, blocks JSONB, created_at TIMESTAMP DEFAULT NOW())');
  return $pdo;
}
